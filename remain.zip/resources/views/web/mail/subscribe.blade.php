<p>Email: {{$email??''}}</p>
<p>Content: {{$content??''}}</p>
<p>Link: {{$link??''}}</p>