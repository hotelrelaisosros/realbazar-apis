<p>Email: {{$email??''}}</p>
<p>Token: {{$token??''}}</p>
<p>Link: {{$link??''}}</p>