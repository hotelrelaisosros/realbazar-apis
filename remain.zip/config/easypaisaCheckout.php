<?php

return [
    'easypaisa' => [
        'STORE_ID'      => 'STOREID',
        'TransactionType'          => 'InitialRequest',
        'HASH_KEY' => 'HASHKEY',

        'POST_BACK_URL'  => '',
        'TRANSACTION_POST_URL'  => '',

    ]
];
