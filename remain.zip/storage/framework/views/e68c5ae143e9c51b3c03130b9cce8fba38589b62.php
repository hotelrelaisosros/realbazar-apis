<p>Email: <?php echo e($email??''); ?></p>
<p>Token: <?php echo e($token??''); ?></p>
<p>Link: <?php echo e($link??''); ?></p><?php /**PATH D:\Codebases\Ecommerce App Codebase\drive-download-20230514T052230Z-001\realbazarapis\realbazarapi-umer\realbazarapi-umer\resources\views/admin/mail/appRegister.blade.php ENDPATH**/ ?>