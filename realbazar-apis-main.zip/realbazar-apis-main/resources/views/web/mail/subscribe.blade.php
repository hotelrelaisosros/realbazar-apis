<p>Email: {{$email??''}}</p>
<p>Content: {{$content??''}}</p>
