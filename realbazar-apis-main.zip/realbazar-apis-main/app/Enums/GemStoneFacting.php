<?php

namespace App\Enums;

enum GemStoneFacting: string
{
    case B = 'Brilliant';
    case CI = 'Crushed Ice';
    case  OMI = 'Old Mint Ice';
}
