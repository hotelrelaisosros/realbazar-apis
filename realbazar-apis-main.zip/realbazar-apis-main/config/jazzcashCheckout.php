<?php

return [
    'jazzcash' => [
        'MERCHANT_ID'      => '',
        'PASSWORD'          => '',
        'INTEGERITY_SALT' => '',
        'CURRENCY_CODE'  => 'PKR',
        'VERSION'         => '2.0',
        'LANGUAGE'       => 'EN',
        'MerchantMPIN'       => '',

        'WEB_RETURN_URL'  => '',
        'RETURN_URL'  => '',
        'TRANSACTION_POST_URL'  => '',
        'MOBILE_REFUND_POST_URL'  => '',
        'CARD_REFUND_POST_URL'  => '',
        'STATUS_INQUIRY_POST_URL'  => '',
    ]
];
