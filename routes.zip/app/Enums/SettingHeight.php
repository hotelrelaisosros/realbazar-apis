<?php

namespace App\Enums;

enum SettingHeight: string
{
    case High = 'High setting';
    case Low = 'Low setting';
}
