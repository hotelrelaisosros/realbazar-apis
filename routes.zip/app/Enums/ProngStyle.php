<?php

namespace App\Enums;

enum ProngStyle: string
{
    case Singular = 'Singular';
    case Compass = 'Compass';
    case Double = 'Double';
}
