<?php

namespace App\Enums;


enum MetalKarat: string
{
    case K14 = '14 Karat';
    case K18 = '18 Karat';
}
